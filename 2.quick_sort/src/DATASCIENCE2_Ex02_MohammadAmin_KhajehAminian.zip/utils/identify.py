def identify(maxVal: int):
    if maxVal > 70:
        print("Win")
    else:
        print("Fail")
