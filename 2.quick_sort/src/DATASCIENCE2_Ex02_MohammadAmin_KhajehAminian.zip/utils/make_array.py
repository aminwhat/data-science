import numpy as np


def make_array(arr):
    narr = np.array(arr)
    return narr
